;;; Computes the factorial of an integer using the (repeat) looping function
(defun fact_iter_r (n / fact)
  ; fact is the product accummulator
  (setq fact 1)

  ; there is no need to multiply by 1, so repeat only (n - 1) times
  (repeat (1- n)
    (setq fact (* fact n)	; multiply by the current n
	  n (1- n)		; decrement n
	  )
    )

  ; we need to evaluate fact so that it is returned
  ; otherwise, the last value of n (namely, 1) would have always been returned
  fact
  )

;;; Computes the factorial of an integer using the
;;; (while) looping function
(defun fact_iter_w (n / fact)
  (setq fact 1)
  
  ; Only the condition changes to  verify each time
  ; if we need to multiply further
  (while (> n 1)    
    (setq fact (* fact n)
	  n (1- n)
	  )
    )
    ; same note as above applies here
    fact
  )


;;; Computes the factorial of an integer using a
;;; recursive algorithm
(defun fact_rec (n)
  (if (zerop n)
    1			; 0! = 1
    (* n (fact_rec (1- n))) ; n! = n * (n-1)!
    )
  )
    
