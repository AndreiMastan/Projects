(defun C:DAVIDCROSS ( / c lrad srad ang THIRTY_DEG SIXTY_DEG cmdecho)
  (setq THIRTY_DEG (/ pi 6)
	SIXTY_DEG (* THIRTY_DEG 2)
    	cmdecho (getvar "CMDECHO")
	)
  (setvar "CMDECHO" 0)
  
  (setq c (getpoint "\nCenter of David's Cross: ")
	lrad (getdist c "\nLarge radius of David's Cross:")
	srad (/ lrad 2 (cos THIRTY_DEG))
	)

  (setq ang 0)
  (repeat 6
    (command "PLINE"
	     (polar c ang srad)
	     (polar c (+ ang THIRTY_DEG) lrad)
	     (polar c (+ ang SIXTY_DEG) srad)
	     ""
	     )
    (setq ang (+ ang SIXTY_DEG))
    )

  (setvar "CMDECHO" cmdecho)
  (princ)
  )