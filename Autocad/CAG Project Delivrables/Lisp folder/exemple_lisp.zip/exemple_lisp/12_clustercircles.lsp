(defun c:clustercircles ( / sset center edata eid etype centergroup)

  ; ask the user to select a set of objects
  (setq sset (ssget))

  (initget 1)
  (setq center (getpoint "Point around which to group the circles:\n"))

  ; iterate over the selection set
  (setq slen (sslength sset)
	ix 0)
  (while (< ix slen)
    (setq edata (entget (ssname sset ix))
	  eid (cdr (assoc -1 edata))
	  etype (cdr (assoc 0 edata))
	  )

    (if (/= etype "CIRCLE")		; not a circle
      (progn
	(princ "Warning! [")
	(princ eid)
	(princ "] was not a [CIRCLE], but a [")
	(princ etype)
	(princ "]; skipped.\n")
	)				; then - progn
      (progn
	(setq centergroup (assoc 10 edata)
	      edata (subst (cons 10 center) centergroup edata)
	      )
	(entmod edata)
	)				; else - progn
      )

    ; next entity in the selection set
    (setq ix (1+ ix))
    )					; while


  (princ)				; don't return anything
  )