; verifies whether a point lies within a rectangular window
(defun insidew (wcorner0 wcorner1 p / xp yp)
  (setq x0 (car wcorner0) y0 (cadr wcorner0)
	x1 (car wcorner1) y1 (cadr wcorner1)
    	xp (car p) yp (cadr p)
	)
  (and (<= (min x0 x1) xp) (<= xp (max x0 x1))
       (<= (min y0 y1) yp) (<= yp (max y0 y1))
       )
  )

; projected distance on the two axes between the points (pX pY)
(defun distproj (p0 p1)
  (list (abs (- (car p0) (car p1)))
	(abs (- (cadr p0) (cadr p1)))
	)
  )

(defun C:CIRCLEC ()
  ; get rectangular constraint and paint it
  (initget 1)
  (setq wcorner0 (getpoint "\nEnter first point of rectangular constraint area: "))
  (initget 1)
  (setq wcorner1 (getpoint "\nEnter second point of rectangular constraint area: "))
  (command "rectangle" wcorner0 wcorner1)

  ; get circle center and apply constraint
  (initget 1)
  (setq ccenter (getpoint "\nEnter center of circle: "))
  (while (not (insidew wcorner0 wcorner1 ccenter))
    (initget 1)
    (setq ccenter (getpoint "\nEnter center of circle: "))
    )

  ; compute projected distances
  (setq projdist0 (distproj wcorner0 ccenter)
	projdist1 (distproj wcorner1 ccenter)
	)

  
  ; get circle radius and apply constraint
  (initget 3)
  (setq crad (getdist ccenter "Enter circle radius: "))
  (while (or (> crad (car projdist0)) (> crad (cadr projdist0))
	     (> crad (car projdist1)) (> crad (cadr projdist1))
	   )
    (initget 3)
    (setq crad (getdist ccenter "Enter circle radius: "))
    )

  ; draw the circle, remove the painted constraint
  (command "circle" ccenter crad)
  (command "erase" wcorner0 "")

  (princ)		; return ""
  )