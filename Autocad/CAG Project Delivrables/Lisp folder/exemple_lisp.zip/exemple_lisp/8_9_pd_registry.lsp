;;; Personal data registry handling functions.
;;; 
;;; The registry is a list containing as entries associative lists with
;;; the following structure:
;;; ((FN . <first name>) (LN . <last name>) (AGE . <age>))
;;; The registry is held in a global variable named PD_DATA.


;; Requests data for a new entry from the user and appends
;; the entry to the registry.
(defun C:PD_ADDENTRY ( / fname lname age entry)
  
  ; get the data from the user
  (initget 1)
  (setq fname (getstring "\nEnter person's first name: "))
  (initget 1)
  (setq lname (getstring "\nEnter person's last name: "))
  (initget 7)
  (setq age (getint "\nEnter person's age: "))

  ; create and append the entry
 
  ; note the usage of the (cons) function with two atom arguments
  ; and that the new entry must be wrapped in a list with the (list)
  ; function prior to being appended to the PD_DATA
  (setq entry (list (cons 'FN fname) (cons 'LN lname) (cons 'AGE age))
	PD_DATA (append PD_DATA (list entry))
	)
  
  ; supress return
  (princ)
  )


;; Lists the contents of the personal data registry in
;; human-readable form.
(defun C:PD_LIST ( / current entry counter)
  
  ; we don't want to destroy the pointer to the actual registry,
  ; so we use an internal var to navigate over the entries
  (setq current PD_DATA
	counter 1)	; this is just for the looks of it

  ; since the navigation pointer will eventually reach the NIL
  ; at the end of the registry list, it's a perfectly good value
  ; to use for the loop test
  (while current
    (setq entry (car current))	; get the data

    ; the actual data is in the CDRs of data items on the
    ; entry's associative list, the CARs are the keys
    (princ (strcat "\nRecord #" (itoa counter)
		   ": " (cdr (assoc 'LN entry))
		   ", " (cdr (assoc 'FN entry))
		   ". Age " (itoa (cdr (assoc 'AGE entry)))
		   )
	   )
    (setq current (cdr current) ; next entry
	  counter (1+ counter)
	  )
    )

  ; suppress return
  (princ)
  )