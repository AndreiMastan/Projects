; Computes the sine of a real number with a given precision
; using the sine Taylor series
(defun sine (x prec / fact p s prevs iter)
  
  ; init accumulators and other parameters
  (setq fact 1.0	; the current factorial of n
	p (float x)	; the current power of x
	s 0.0		; current sine series value
	prevs 1.0	; previous sine series value; used in termination check
	n 1		; current index
	signum 1)	; the signum of the current term to add to the series
  
  (while (> (abs (- s prevs)) prec)
    (setq prevs s
	  s (+ s (* signum (/ p fact)))
	  p (* p x x)		; powers jump 2 by 2
	  n (1+ n)
	  fact (* fact n)
	  n (1+ n)
	  fact (* fact n)	; same for factorial
	  signum (- 0 signum)	; invert signum
	  )
    ; debug output, suppressed
    ; (princ (strcat "s=" (rtos s) ", n=" (itoa n) ", x^n=" (rtos p) ", n!=" (rtos fact) "\n"))
    )
  
  ; return the (approximate) sine
  s
  )
    