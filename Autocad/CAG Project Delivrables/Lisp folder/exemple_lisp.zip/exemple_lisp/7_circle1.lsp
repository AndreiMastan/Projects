;;; Sample redefinition of CIRCLE command in its simplest form
(defun C:CIRCLE1 (/ c rad cmdecho)
  
  ; save the environment status
  (setq cmdecho (getvar "CMDECHO"))
  
  ; customize the environment as needed
  ; in our case, disable that garbage-generator command echo
  (setvar "CMDECHO" 0)

  ; get the circle parameters using iniget / getXXX
  (initget 1)
  (setq c (getpoint "\nChoose center point for circle:"))
  (initget 7)
  (setq rad (getdist c "\nChoose circle radius:"))

  ; draw the circle
  (command "circle" c rad)

  ; restore the environment to its previous state
  (setvar "CMDECHO" cmdecho)

  ; supress return value
  (princ)
 )