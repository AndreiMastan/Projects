#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>


int state = 1;
GLfloat	rtri = 0.0f;				
GLfloat	rquad = 0.0f;				
GLfloat speed = 0.2f;
bool	help = false;

GLvoid glPrint(GLint x, GLint y, const char *string, ...);
void ViewOrtho(int x, int y);
void ViewPerspective(void);

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glLoadIdentity();									
	glTranslatef(-1.5f,0.0f,-6.0f);					
	
	glColor3f (0.0, 0.0, 0.0);
	if (help) {
		glPrint(5, 20, "1: Afiseaza cele doua primitive folosind culorile predefinite din mediul OpenGL");
		glPrint(5, 37, "2: Afiseaza cele doua primitive folosind cu culori definite de catre programator");
		glPrint(5, 54, "3: Porneste miscarea de rotatie aleatore a celor doua primitive bidimensionale");
		glPrint(5, 71, "4: Porneste miscarea de rotatie aleatore a celor doua obiecte 3D ce au la baza primitivele bidimensionale");
	}
	
	switch(state) {
	case 1:
		glBegin(GL_TRIANGLES);							
		glVertex3f( 0.0f, 1.0f, 0.0f);				
		glVertex3f(-1.0f,-1.0f, 0.0f);				
		glVertex3f( 1.0f,-1.0f, 0.0f);				
		glEnd();											
		
		glLoadIdentity();									
		glTranslatef(1.5f,0.0f,-6.0f);						
		glBegin(GL_QUADS);									
		glVertex3f(-1.0f, 1.0f, 0.0f);					
		glVertex3f( 1.0f, 1.0f, 0.0f);				
		glVertex3f( 1.0f,-1.0f, 0.0f);				
		glVertex3f(-1.0f,-1.0f, 0.0f);				
		glEnd();
		glutSwapBuffers();
		break;
	case 2:
		glBegin(GL_TRIANGLES);							
		glColor3f(1.0f,0.0f,0.0f);						
		glVertex3f( 0.0f, 1.0f, 0.0f);					
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f(-1.0f,-1.0f, 0.0f);				
		glColor3f(0.0f,0.0f,1.0f);						
		glVertex3f( 1.0f,-1.0f, 0.0f);				
		glEnd();											
		
		glLoadIdentity();									
		glTranslatef(1.5f,0.0f,-6.0f);						
		glColor3f(0.5f,0.5f,1.0f);							
		glBegin(GL_QUADS);									
		glVertex3f(-1.0f, 1.0f, 0.0f);					
		glVertex3f( 1.0f, 1.0f, 0.0f);					
		glVertex3f( 1.0f,-1.0f, 0.0f);				
		glVertex3f(-1.0f,-1.0f, 0.0f);					
		glEnd();
		glutSwapBuffers();
		break;
	case 3:
		glRotatef(rtri,0.0f,1.0f,0.0f);					
		glBegin(GL_TRIANGLES);								
		glColor3f(1.0f,0.0f,0.0f);						
		glVertex3f( 0.0f, 1.0f, 0.0f);					
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f(-1.0f,-1.0f, 0.0f);					
		glColor3f(0.0f,0.0f,1.0f);						
		glVertex3f( 1.0f,-1.0f, 0.0f);					
		glEnd();										
		
		glLoadIdentity();								
		glTranslatef(1.5f,0.0f,-6.0f);					
		glRotatef(rquad,1.0f,0.0f,0.0f);				
		glColor3f(0.5f,0.5f,1.0f);						
		glBegin(GL_QUADS);								
		glVertex3f(-1.0f, 1.0f, 0.0f);					
		glVertex3f( 1.0f, 1.0f, 0.0f);					
		glVertex3f( 1.0f,-1.0f, 0.0f);					
		glVertex3f(-1.0f,-1.0f, 0.0f);					
		glEnd();
		glutSwapBuffers();
		break;
	case 4:
		glRotatef(rtri,0.0f,1.0f,0.0f);						
		glBegin(GL_TRIANGLES);								
		glColor3f(1.0f,0.0f,0.0f);						
		glVertex3f( 0.0f, 1.0f, 0.0f);					
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f(-1.0f,-1.0f, 1.0f);				
		glColor3f(0.0f,0.0f,1.0f);					
		glVertex3f( 1.0f,-1.0f, 1.0f);				
		glColor3f(1.0f,0.0f,0.0f);					
		glVertex3f( 0.0f, 1.0f, 0.0f);					
		glColor3f(0.0f,0.0f,1.0f);					
		glVertex3f( 1.0f,-1.0f, 1.0f);				
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f( 1.0f,-1.0f, -1.0f);				
		glColor3f(1.0f,0.0f,0.0f);						
		glVertex3f( 0.0f, 1.0f, 0.0f);					
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f( 1.0f,-1.0f, -1.0f);					
		glColor3f(0.0f,0.0f,1.0f);						
		glVertex3f(-1.0f,-1.0f, -1.0f);				
		glColor3f(1.0f,0.0f,0.0f);					
		glVertex3f( 0.0f, 1.0f, 0.0f);				
		glColor3f(0.0f,0.0f,1.0f);						
		glVertex3f(-1.0f,-1.0f,-1.0f);					
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f(-1.0f,-1.0f, 1.0f);					
		glEnd();											
		
		glLoadIdentity();									
		glTranslatef(1.5f,0.0f,-7.0f);						
		glRotatef(rquad,1.0f,1.0f,1.0f);					
		glBegin(GL_QUADS);									
		glColor3f(0.0f,1.0f,0.0f);						
		glVertex3f( 1.0f, 1.0f,-1.0f);					
		glVertex3f(-1.0f, 1.0f,-1.0f);					
		glVertex3f(-1.0f, 1.0f, 1.0f);					
		glVertex3f( 1.0f, 1.0f, 1.0f);					
		glColor3f(1.0f,0.5f,0.0f);						
		glVertex3f( 1.0f,-1.0f, 1.0f);					
		glVertex3f(-1.0f,-1.0f, 1.0f);					
		glVertex3f(-1.0f,-1.0f,-1.0f);				
		glVertex3f( 1.0f,-1.0f,-1.0f);					
		glColor3f(1.0f,0.0f,0.0f);						
		glVertex3f( 1.0f, 1.0f, 1.0f);			
		glVertex3f(-1.0f, 1.0f, 1.0f);				
		glVertex3f(-1.0f,-1.0f, 1.0f);					
		glVertex3f( 1.0f,-1.0f, 1.0f);				
		glColor3f(1.0f,1.0f,0.0f);					
		glVertex3f( 1.0f,-1.0f,-1.0f);				
		glVertex3f(-1.0f,-1.0f,-1.0f);				
		glVertex3f(-1.0f, 1.0f,-1.0f);					
		glVertex3f( 1.0f, 1.0f,-1.0f);					
		glColor3f(0.0f,0.0f,1.0f);						
		glVertex3f(-1.0f, 1.0f, 1.0f);				
		glVertex3f(-1.0f, 1.0f,-1.0f);					
		glVertex3f(-1.0f,-1.0f,-1.0f);					
		glVertex3f(-1.0f,-1.0f, 1.0f);					
		glColor3f(1.0f,0.0f,1.0f);						
		glVertex3f( 1.0f, 1.0f,-1.0f);					
		glVertex3f( 1.0f, 1.0f, 1.0f);					
		glVertex3f( 1.0f,-1.0f, 1.0f);					
		glVertex3f( 1.0f,-1.0f,-1.0f);				
		glEnd();
		glutSwapBuffers();
		break;
	}
	
}
void init (void)
{
	glShadeModel (GL_SMOOTH);							
	
	glClearColor(1.0f, 1.0f, 1.0f, 0.5f);			
	glClearDepth(1.0f);									
	
	glEnable(GL_DEPTH_TEST);							
	glEnable (GL_LINE_SMOOTH);
	glDepthFunc(GL_LEQUAL);							
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	
	
	glViewport(0,0,800,600);							
	
	glMatrixMode(GL_PROJECTION);						
	glLoadIdentity();								
	
	gluPerspective(45.0f,800.0/600.0,0.1f,100.0f);
	
	glMatrixMode(GL_MODELVIEW);						
	glLoadIdentity();									
}


void spinDisplay(void)
{
	rtri += speed;										
	rquad -= speed - 0.05f;
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y){
	switch(key) {
	case '1':
		state = 1;
		rtri = 0.0f;										
		rquad = 0.0f;
		glutIdleFunc(NULL);
		glutPostRedisplay();
		break;
	case '2':
		state = 2;
		rtri = 0.0f;										
		rquad = 0.0f;
		glutIdleFunc(NULL);
		glutPostRedisplay();
		break;
	case '3':
		state = 3;
		glutIdleFunc(spinDisplay);
		break;
	case '4':
		state = 4;
		glutIdleFunc(spinDisplay);
		break;
	case 'h':
		if (help) {
			help = false;
		}else{
			help = true;
		}
		glutPostRedisplay();
		break;
	case 45: /* + */
		speed -= 0.05;
		break;
	case 43: /* - */
		speed += 0.05;
		break;
	case 27: /* Tasta Escape */
		exit(0);
		break;
	default:
		printf("%d\n", key);
	}
}


int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize (800,600);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("Exemplul 1");
	init ();
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}

GLvoid glPrint(GLint x, GLint y, const char *string, ...)		
{
	int			len, i;
	char		text[256];										
	va_list		ap;												
	
	if (string == NULL)										
		return;												
	
	va_start(ap, string);									
	vsprintf(text, string, ap);								
	va_end(ap);
	
	ViewOrtho(800, 600);
	
	glRasterPos2f(x, y);
	
	len = (int) strlen(text);
	
	for (i = 0; i < len; i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, text[i]);
	}
	ViewPerspective();
}

void ViewOrtho(int x, int y)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho( 0, x , y , 0, -1, 1 );
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
}

void ViewPerspective(void)
{
	glMatrixMode( GL_PROJECTION );
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}